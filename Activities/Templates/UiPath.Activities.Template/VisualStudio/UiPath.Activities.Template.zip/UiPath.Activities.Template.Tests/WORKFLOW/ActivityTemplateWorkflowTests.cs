﻿using Xunit;

namespace $safeprojectname$.Workflow
{
    public class ActivityTemplateWorkflowTests
    {
        [Fact]
        public void Test()
        {
            Assert.Equal(0, 0);
        }

    }
}
