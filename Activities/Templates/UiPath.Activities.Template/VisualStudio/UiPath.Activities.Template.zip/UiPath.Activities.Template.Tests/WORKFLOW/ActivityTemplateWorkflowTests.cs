﻿using Xunit;

namespace $safeprojectname$.Tests.Workflow
{
    public class ActivityTemplateWorkflowTests
    {
        [Fact]
        public void Test()
        {
            Assert.Equal(0, 0);
        }

    }
}
