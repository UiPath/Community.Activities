﻿using Xunit;

namespace $safeprojectname$.Unit
{
    public class ActivityTemplateUnitTests
    {
        [Fact]
        public void Test()
        {
            Assert.Equal(0, 0);
        }
    }
}
